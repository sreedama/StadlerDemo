/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_CUSTOM_2021_12_WEIGHTMANAGEMENT_HXX 
#define TEAMCENTER_SERVICES_CUSTOM_2021_12_WEIGHTMANAGEMENT_HXX





#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <Custom_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}
namespace SR5 { namespace Services { namespace Custom { namespace _2021_12 { class WeightManagementIiopSkeleton; }}}}


namespace SR5
{
    namespace Soa
    {
        namespace Custom
        {
            namespace _2021_12
            {
                class WeightManagement;
            }
        }
    }
}


class SOACUSTOM_API SR5::Soa::Custom::_2021_12::WeightManagement

{
public:

    static const std::string XSD_NAMESPACE;

    struct DataResponse;
    struct ErrorResponse;
    struct WeightResponse;

    struct  DataResponse
    {
        /**
         * weight
         */
        double weight;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class SR5::Services::Custom::_2021_12::WeightManagementIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="DataResponse" );
    };

    struct  ErrorResponse
    {
        /**
         * Error code
         */
        int errorCode;
        /**
         * Error text
         */
        std::string errorText;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class SR5::Services::Custom::_2021_12::WeightManagementIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="ErrorResponse" );
    };

    struct  WeightResponse
    {
        /**
         * Data response
         */
        DataResponse dataResponse;
        /**
         * Error response
         */
        ErrorResponse errorResponse;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class SR5::Services::Custom::_2021_12::WeightManagementIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="WeightResponse" );
    };



    WeightManagement();
    virtual ~WeightManagement();
    

    /**
     * .
     *
     * @param uid
     *        Uid
     *
     * @return
     *
     *
     * @version Teamcenter 13.3
     */
    virtual WeightResponse calculateAndSetWeight ( const std::string uid ) = 0;


};

#include <Custom_undef.h>
#endif


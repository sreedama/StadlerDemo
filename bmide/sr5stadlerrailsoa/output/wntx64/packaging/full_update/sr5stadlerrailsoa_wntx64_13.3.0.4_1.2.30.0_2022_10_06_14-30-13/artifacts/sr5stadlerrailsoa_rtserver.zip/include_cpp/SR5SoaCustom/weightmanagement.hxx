/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_CUSTOM_WEIGHTMANAGEMENT_HXX 
#define TEAMCENTER_SERVICES_CUSTOM_WEIGHTMANAGEMENT_HXX


#include <weightmanagement2112.hxx>


namespace SR5
{
    namespace Soa
    {
        namespace Custom
        {
            class WeightManagement;
        }
    }
}


/**
 * Weight management service.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libsr5soacustom.dll
 * </li>
 * </ul>
 */

class SR5::Soa::Custom::WeightManagement
    : public SR5::Soa::Custom::_2021_12::WeightManagement
{};

#endif


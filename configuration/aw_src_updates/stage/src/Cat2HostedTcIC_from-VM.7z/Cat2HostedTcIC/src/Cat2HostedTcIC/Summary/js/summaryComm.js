(function(MY_SUMMARY_COMM){
	
	var mylog = function(msg) {}	
	
	var initMsg = {
			'op': 'init',
			'data': {
				'version': 1  // Not used by this prototype, but could be used to detect mismatched/old JavaScript version 
			}
	}
	
	function makeSocket()
	{
		var socket;
		try
		{
		    mylog("makeSocket=" + 'ws://' + window.location.host + '/ws/main');
		    throw "Something bad happened";
		    socket = new WebSocket('ws://' + window.location.host + '/ws/main');
		    debugLog("Create WebSocket connection:\n\t--> " + 'ws://' + window.location.host + '/ws/main');
        }
		catch (e)
		{
            mylog('exception creating WebSocket: '+e);
            debugLog('Exception during creating WebSocket: '+ e);
        }
		
        if (socket)
        {
            socket.onopen = function(event)
            {
            	try
            	{
            		var msg = formatSocketMsg(initMsg);
	            	mylog("send init msg=" + msg);
	            	debugLog('Send \"init\" message on WebSocket:\n\t--> '+ msg);
	            	socket.send(msg);
            	}
                catch(e)
                {
                	debugLog('Exception during sending \"init\" message on WebSocket:\n\t--> '+ e);     
                }
            }
        }
        return socket;
	}
	
	var token = undefined;
	function getSocketToken()
	{
	    if (typeof token === 'undefined')
	    {
	    	try
            { 
	    		token = null;
		    	if (location.search.length > 1)
		    	{
			    	var params = location.search.substr(1).split("&");
			    	for (var i = 0; i < params.length; ++i) {
						var kv = params[i].split("=");
						var key = decodeURIComponent(kv[0]);
						if (key == 'token' && kv.length > 1) {
							token = decodeURIComponent(kv[1]);
							break;
						}
			    	}
		    	}
            }
            catch(e)
            {
            	debugLog('Exception during getSocketToken: '+ e);
            }
	    }
	    return token;
	}
	
	function formatSocketMsg(msg)
	{
		msg.token = getSocketToken();
		return JSON.stringify(msg);
	}
	
	function CommService(direct, localPort, logger)
	{
		if (logger) mylog = logger;

		var handlers = {};
		this.registerHandler = function(op, callback) {
			handlers[op] = callback;
		}
		function notifyHandler(msg)
		{
			var handler = handlers[msg.op];
			
            if (handler) {
                handler(msg.data);
            }
		}

		if (direct)
		{
			var socket;
			this.connect = function()
			{
				mylog("Create WebSocket connection");
		        socket = makeSocket();
		        if (!socket)
		        {
		        	mylog("Failed to create WebSocket");
		        	return;
		        }

		        socket.onmessage = function(event)
		        {
		        	notifyHandler(JSON.parse(event.data));
		        }
			}

			this.sendMessage = function(msg)
			{
				if (socket)
				{
					try
                    {
						socket.send(formatSocketMsg(msg));                    
	  				}
	                catch(e)
	                {
	                	mylog("Exception during sending message on WebSocket: "+ e); 
	                }
			    }
			}
		}
		else
		{
			var wrapperOrigin = 'http://localhost:'+localPort;
			this.connect = function() {
				function message(event) {
	        		if (event.origin.toLowerCase()  !== wrapperOrigin.toLowerCase()) {
	        			mylog("Unexpected event origin:\n\t--> event.origin= "+event.origin + "\n\t--> wrapperOrigin= " + wrapperOrigin);
	        			return;
	        		}

        			notifyHandler(event.data);
	        	}
	        	window.addEventListener('message', message, false);	        	
	        	this.sendMessage(initMsg);
			}
        	
			this.sendMessage = function(msg)
			{
				window.parent.postMessage(msg, wrapperOrigin);
			}
		}
	}
	MY_SUMMARY_COMM.CommService = CommService;	
	
})(window.MY_SUMMARY_COMM = window.MY_SUMMARY_COMM || {});
/**
 * History.js 
 */

(function (TcICHistory) {

    var isCacheEnable = true;
    try {
        /*This will throw an exception in some browsers when cookies/localStorage/sessionStorage are explicitly disabled (i.e. Chrome)*/
        sessionStorage = window.sessionStorage;
        sessionStorage.setItem('TEST', '1');
        sessionStorage.removeItem('TEST');
    } catch (e) {
        isCacheEnable = false;
    }

    TcICHistory.strcmp = function (a, b) {
        return (a < b ? -1 : (a > b ? 1 : 0));
    };

    TcICHistory.arrayContainsString = function (array, string) {
        var newArr = array.filter(function (el) {
            return el.indexOf(string) >= 0;
        });
        return newArr.length > 0;
    };

    TcICHistory.resetHistory = function () {
        if (isCacheEnable) {
            sessionStorage.removeItem("AWTcICHosted_History_LastURL");
            sessionStorage.removeItem("AWTcICHosted_History_Index");
            sessionStorage.removeItem("AWTcICHosted_History_List");
        }
    };

    TcICHistory.addNewUrl = function (i_current_url) {

        if (!isCacheEnable) {
            return;
        }
        var location_history;
        var location_history_index = 0;
        var last_url = sessionStorage.getItem("AWTcICHosted_History_LastURL");
        if ((last_url != undefined) && (last_url != null)) {
            if (TcICHistory.strcmp(last_url, i_current_url) != 0) {
                var str_index = sessionStorage.getItem("AWTcICHosted_History_Index");
                //get a numeric value from str_index, put it in location_history_index
                if (str_index == undefined || str_index == null || str_index == "null") {
                    location_history_index = 0;
                } else {
                    location_history_index = parseInt(str_index);
                }

                try {
                    location_history = JSON.parse(sessionStorage.getItem("AWTcICHosted_History_List")) || [];
                } catch (err) {
                    location_history = [];
                }

                if ((location_history != undefined) && (location_history != null)) {
                    if (TcICHistory.arrayContainsString(location_history, i_current_url)) {
                        /*existing page*/

                    } else {

                        /*delete (location_history.length - location_history_index -1) elements of the location_history array starting from the (location_history_index +1) element*/
                        var indx = location_history_index + 1;
                        location_history.splice(indx, (location_history.length - location_history_index - 1));
                        location_history.push(i_current_url);
                        location_history_index++;
                    }

                    sessionStorage.setItem("AWTcICHosted_History_LastURL", i_current_url);
                    sessionStorage.setItem("AWTcICHosted_History_Index", location_history_index);
                    sessionStorage.setItem("AWTcICHosted_History_List", JSON.stringify(location_history));
                } else {
                    MY_COMM.debugLog('Error: AWTcICHosted_History_List is undefined');
                }

            }
        } else {
            sessionStorage.setItem("AWTcICHosted_History_LastURL", i_current_url);
            location_history_index = 0;
            location_history = [];
            location_history.push(i_current_url);
            sessionStorage.setItem("AWTcICHosted_History_Index", location_history_index);
            sessionStorage.setItem("AWTcICHosted_History_List", JSON.stringify(location_history));
        }

    };

    TcICHistory.getBackUrl = function () {
        var url = null;
        var location_history_index = 0;
        if (!isCacheEnable) {
            return url;
        }
        var str_index = sessionStorage.getItem("AWTcICHosted_History_Index");
        //get a numeric value from str_index, put it in location_history_index
        if (str_index == undefined || str_index == null || str_index == "null") {
            location_history_index = 0;
        } else {
            location_history_index = parseInt(str_index);
        }
        if (location_history_index != undefined) {
            if (location_history_index > 0) {
                var location_history;
                try {
                    location_history = JSON.parse(sessionStorage.getItem("AWTcICHosted_History_List")) || [];
                    url = location_history[location_history_index];
                    sessionStorage.setItem("AWTcICHosted_History_LastURL", url);
                    location_history_index--;
                    url = location_history[location_history_index];
                    sessionStorage.setItem("AWTcICHosted_History_Index", location_history_index);
                } catch (err) {

                }
            }
        }
        return url;
    };

    TcICHistory.getForwardUrl = function () {
        var url = null;
        if (!isCacheEnable) {
            return url;
        }
        try {
            var location_history_index = 0;
            var str_index = sessionStorage.getItem("AWTcICHosted_History_Index");
            //get a numeric value from str_index, put it in location_history_index
            if (str_index == undefined || str_index == null || str_index == "null") {
                location_history_index = 0;
            } else {
                location_history_index = parseInt(str_index);
            }
            var location_history = JSON.parse(sessionStorage.getItem("AWTcICHosted_History_List")) || [];
            if ((location_history_index != undefined) && (location_history != undefined)) {
                if (location_history_index < location_history.length - 1) {
                    url = location_history[location_history_index];
                    sessionStorage.setItem("AWTcICHosted_History_LastURL", url);
                    location_history_index++;
                    url = location_history[location_history_index];
                    sessionStorage.setItem("AWTcICHosted_History_Index", location_history_index);
                }
            }

        } catch (err) {

        }

        return url;
    };

})(window.TcICHistory = window.TcICHistory || {});
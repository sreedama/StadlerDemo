(function(MY_HOST){

    // Logging function which appends to a specific div in the page.
    // Useful for demonstration with embedded web browsers which don't
    // provide any/easy access to the browser console.
    function mylog(msg)
    {
        var con = document.getElementById("console");
        var line = document.createTextNode(msg + "\n");
        con.appendChild(line);
        con.scrollTop = con.scrollHeight;
    }
    
    MY_HOST.mylog = mylog;
    
    // Inspect query params to determine integration port number, and
    // flag which indicates if we're running from the local process or AW server
    var localPort = 3000; // default
    var directComm = true; // default
    if (location.search.length > 1)
    {
        var params = location.search.substr(1).split("&");
        for (var i = 0; i < params.length; ++i)
        {
            var kv = params[i].split("=");
            var key = decodeURIComponent(kv[0]);
            if (key == 'port' && kv.length > 1)
            {
                localPort = decodeURIComponent(kv[1]);
            }
            else if (key == 'direct' && kv.length > 1) {
                directComm = decodeURIComponent(kv[1]) === 'true';
            }
        }
    }
   
    var myCommSvc = null;
    var hostControl = null;

    
    // utility function for creating a single InteropObjectRef instances from an object with uid, db, and type properties
    function makeObjectRef(obj) {
        return new INF_SERVICES_CORE_2014_02.InteropObjectRef(obj.uid, obj.db, obj.type);
    }

    // utility function for creating array of InteropObjectRef instances from objects with uid, db, and type properties
    function makeObjectRefs(objs) {
        var refs = [];

        if (objs)
        {
            if (Array.isArray(objs))
            {
                for (var i=0; i<objs.length; ++i)
                {
                    refs.push(makeObjectRef(objs[i]));
                }
            }
            else if (objs.uid)
            {
                // looks like just one object
                refs.push(makeObjectRef(objs));
            }
        }

        return refs;
    }
    
    function makeDataRef(data, type) {
        return new INF_SERVICES_CORE_2014_10.InteropObjectRef( JSON.stringify(data), type );
    }

    // utility function for creating UID Selection data references
    function makeSelections(objs)
    {
        var sels = [];
        
        if (objs) {
            if (Array.isArray(objs))
            {
                for (var i=0; i<objs.length; ++i)
                {
                    sels.push(makeDataRef(makeObjectRef(objs[i]), 'UID'));
                }
            }
            else if (objs.product)
            {
                sels.push(makeDataRef(makeObjectRef(objs), 'UID'));
            }
        }

        return sels;
    }

    // utility function for creating Occurrence Selection data references
    function makeOccSelections(occs) {
        var sels = [];
        
        if (occs) {
            if (Array.isArray(occs)) {
                for (var i=0; i<occs.length; ++i) {
                    var o = occs[i];
                    var sel = new SOL_SERVICES_SELECTION_2014_10.OccSelection();
                    sel.InitStableIdThreadPath(o.path, makeObjectRef(o.product));
                    sel.Awb0OccurrenceObj = new INF_SERVICES_CORE_2014_02.InteropObjectRef('', '', ''); // TODO seems like a bug that we have to initialize this
                    sels.push(makeDataRef(sel, 'Occurrence'));
                }
            } else if (occs.product) {
                var sel = new SOL_SERVICES_SELECTION_2014_10.OccSelection();
                sel.InitStableIdThreadPath(occs.path, makeObjectRef(occs.product));
                sel.Awb0OccurrenceObj = new INF_SERVICES_CORE_2014_02.InteropObjectRef('', '', ''); // TODO seems like a bug that we have to initialize this
                sels.push(makeDataRef(sel, 'Occurrence'));
            }
        }

        return sels;
    }
    

    //
    // AW Host side configuration service
    //
    function MyHostConfiguration() {
        INF_SERVICES_CORE_2014_07.IHostConfigurationHandler.call(this);
    }

    MyHostConfiguration.prototype = Object.create(INF_SERVICES_CORE_2014_07.IHostConfigurationHandler.prototype);

    // Default settings -- can be overridden by initComplete/initAW
    var host_consfiguration_show = false;
    var hostConfigurationSettings = {
            AllowGoHome: 'true',
            AllowThemeChange: 'true',
            AllowGroupRoleChange: 'false',
            HostType: 'MyHostTest',
            HasFullScreenSupport: 'false',
            ShowSiemensLogo: 'true',
            Theme: 'com.siemens.splm.clientfx.ui.lightTheme',
            HostSupportsMultipleSelection: 'true',
    };
    MyHostConfiguration.prototype.handleHostConfigurationRequest = function ()
    {
        mylog("host settings request");
        var host_setting_info = "";
        var settings = [];
        for (var prop in hostConfigurationSettings) {
            settings.push(new INF_SERVICES.Pair(prop, hostConfigurationSettings[prop]));
            host_setting_info=host_setting_info + "\n\t\t- " + prop + "= " + hostConfigurationSettings[prop]; 
        }
        if(!host_consfiguration_show){
        	myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"\t--> Host Configuration Settings: " + host_setting_info}});
        	host_consfiguration_show = true;
        }
        return new INF_SERVICES_CORE_2014_07.HostConfigurationResponseMsg(settings);
    };


    //
    // AW Host side logging handler
    //
    function MyLogEntryHandler () {
        INF_SERVICES_LOGGING_2014_02.ILogEntryHandler.call(this);
    }

    MyLogEntryHandler.prototype = Object.create(INF_SERVICES_LOGGING_2014_02.ILogEntryHandler.prototype);

    MyLogEntryHandler.prototype.handleEntry = function (msg) {
        // Log to page
        mylog("LOG: " + msg.getFormatMessage());
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :msg.getFormatMessage()}});
        // And Log to websocket
        myCommSvc.sendMessage({op: 'log', data: msg});
    };


    //
    // AW Host side client status handler
    //
    function MyClientStatusHandler () {
        INF_SERVICES_CORE_2014_07.IClientStatusHandler.call(this);
    }
    
    MyClientStatusHandler.prototype = Object.create(INF_SERVICES_CORE_2014_07.IClientStatusHandler.prototype);

    MyClientStatusHandler.prototype.handleClientStatusUpdate = function (msg)
    {
        mylog("Client Status: " + msg.Status);
        //And send to server
        myCommSvc.sendMessage({op: 'ClientStatus', data: msg.Status});
    }


    //
    // AW Host side selection change listener
    //
    function MySelectionChangeListener2014_10 ()
    {
        SOL_SERVICES_SELECTION_2014_10.ISelectionChangedListener.call(this);
    }

    MySelectionChangeListener2014_10.prototype = Object.create(SOL_SERVICES_SELECTION_2014_10.ISelectionChangedListener.prototype);

    MySelectionChangeListener2014_10.prototype.selectionChange = function (event) {
        // Log to page
        mylog("selections = " + JSON.stringify(event.getSelection()));
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"selection\" notification:\n\t--> " + JSON.stringify(event.getSelection())}});
        // And send to server
        myCommSvc.sendMessage({op: 'selection', data: event.getSelection()});
    };

    //
    // Host function for setting selection in AW
    //
    var selectionListenerProxy = null;
    function setSelection(data) {
        if (null === selectionListenerProxy) {
            selectionListenerProxy = new SOL_SERVICES_SELECTION_2014_10.SelectionListenerProxy(hostControl);
        }

        var selections = null;

        if (data.selections) {
            selections = makeSelections(data.selections);
        } else if (data.occSelections) {
            selections = makeOccSelections(data.occSelections);
        }
        
        if (selections) {
    		selectionListenerProxy.targetSelectionChanged2( selections, selections.length > 1 );
        }
    }


    //
    // AW Host side clipboard change listener
    //
    function MyRemoteClipboardChangeListener() {
        SOL_SERVICES_CLIPBOARD_2014_02.IRemoteClipboardChangeListener.call(this);
    }
    
    MyRemoteClipboardChangeListener.prototype = Object.create(SOL_SERVICES_CLIPBOARD_2014_02.IRemoteClipboardChangeListener.prototype);
    
    MyRemoteClipboardChangeListener.prototype.remoteClipboardChange = function( message ) {
        // Log to page
        mylog("clipboard = " + JSON.stringify(message));
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"clipboard\" notification:\n\t--> " + JSON.stringify(message)}});
        // And send to server
        myCommSvc.sendMessage({op: 'clipboard', data: message});
    }

    //
    // Host function for setting clipboard in AW
    //
    var remoteClipboardProxy = null;
    function setClipboard(data) {
        if (null === remoteClipboardProxy) {
            remoteClipboardProxy = new SOL_SERVICES_CLIPBOARD_2014_02.RemoteClipboardProxy(hostControl);
        }

        if (data.clear) {
            remoteClipboardProxy.clearRemoteClipboard();
        }
        
        if (data.add || data.remove) {
            // TODO do the individual addToRemoteClipboard and removeFromRemoteClipboard
            // methods need to be exposed to the Java side??
            var add = makeObjectRefs(data.add);
            var remove = makeObjectRefs(data.remove);
            remoteClipboardProxy.updateRemoteClipboard(add, remove);
        }
    }


    //
    // AW Host side refresh change listener
    //
    function MyRefreshHandler() {
        INF_SERVICES_REFRESH_2014_07.IRefreshHandler.call(this);
    }
    
    MyRefreshHandler.prototype = Object.create(INF_SERVICES_REFRESH_2014_07.IRefreshHandler.prototype);
    
    MyRefreshHandler.prototype.refreshHost = function( message ) {
        // Log to page
        mylog("refresh = " + JSON.stringify(message));
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"refresh\" notification:\n\t--> " + JSON.stringify(message)}});
        // And send to server
        myCommSvc.sendMessage({op: 'refresh', data: message});
    }
    
    //
    // Host function for passing refresh / object changes to AW
    //
    var refreshProxy = null;
    function sendRefresh(data)
    {
        if (null === refreshProxy)
        {
            refreshProxy = new INF_SERVICES_REFRESH_2014_07.RefreshProxy(hostControl);
        }
        
        refreshProxy.sendRefresh(
                makeObjectRefs(data.createdObjects),
                makeObjectRefs(data.deletedObjects),
                makeObjectRefs(data.updatedObjects),
                makeObjectRefs(data.plainObjects),
                makeObjectRefs(data.childChangeObjects),
                makeObjectRefs(data.dataObjects)
        );
    }
    
    function sendRefreshAWHostedPage()
    {
    	var clientIFrame = document.getElementById("aw-frame");
    	myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Receive \"RefreshAWHostedPage\" message"}});
  		clientIFrame.contentWindow.location.reload();
    }
		
    
    function sendGoBackOnePage()
    {
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Receive \"GoBackOnePage\" message"}});        
        var url = TcICHistory.getBackUrl();
        if (url != null){    
          
            var clientIFrame = document.getElementById("aw-frame");
            clientIFrame.contentWindow.location = url;
        }
    }
    
    function sendGoForwardOnePage()
    {
    	myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Receive \"GoForwardOnePage\" message"}});
		var url = TcICHistory.getForwardUrl();
        if (url != null){
            var clientIFrame = document.getElementById("aw-frame");
            clientIFrame.contentWindow.location = url;
        }
    }
    
    function  getCurrentAwFrameUrl()
    {
        var clientIFrame = document.getElementById("aw-frame");
        var current_url = clientIFrame.contentWindow.location.href;
        var msg = {'op': 'getCurrentAwFrameUrl','data':{'url' : ""}}
        msg.data.url = current_url;
        myCommSvc.sendMessage(msg);
    }
    
    //
    // AW Host side session change listener
    //
    function MySessionHandler() {
        INF_SERVICES_SESSION_2014_07.ISessionHandler.call(this);
    }
    
    MySessionHandler.prototype = Object.create(INF_SERVICES_SESSION_2014_07.ISessionHandler.prototype);
    
    MySessionHandler.prototype.handle = function( message ) {
        // Log to page
        mylog("session = " + JSON.stringify(message));
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"session\" notification:\n\t--> " + JSON.stringify(message)}});
        // And send to server
        myCommSvc.sendMessage({op: 'session', data: message});
    }

    //
    // Host function for passing session changes to AW
    //
    var sessionProxy = null;
    function sendSession(data) {
        if (null === sessionProxy) {
            sessionProxy = new INF_SERVICES_SESSION_2014_07.SessionProxy(hostControl);
        }
        
        sessionProxy.sendSession(
                makeObjectRefs(data.sessionObjects),
                data.preferences
        );
    }


    //
    // Host function for opening an object in a location in AW
    //
    var openLocationProxy = null;
    function openLocation(data) {
        if (openLocationProxy === null) {
            openLocationProxy = new INF_SERVICES_OPENLOCATION_2014_02.OpenLocationProxy(hostControl);
        }
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Receive \"openLocation\" message"}});
        openLocationProxy.openLocation(data.location, makeObjectRefs(data.objects));
    }


    //
    // AW Host Open
    //
    function MyHostOpenHandler () {
        SOL_SERVICES_OPEN_2014_02.IHostOpenHandler.call(this);
    }

    MyHostOpenHandler.prototype = Object.create(SOL_SERVICES_OPEN_2014_02.IHostOpenHandler.prototype);

    MyHostOpenHandler.prototype.handleOpen = function (message) {
        var logMsg = "**** [Host Open 2014_02 Message]\n";
        var targets = message.OpenTargets || [];
        for (var i = 0; i < targets.length; i++) {
            logMsg += "  [" + i + "]:" + targets[i].ObjId + " - " + targets[i].ObjType + "\n";
        }
        logMsg += "****";

        mylog(logMsg);
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"open\" notification:\n\t--> " + logMsg}});
        myCommSvc.sendMessage({op: 'open', data: message});
    };

    function MyHostOpenHandler2 () {
        SOL_SERVICES_OPEN_2015_10.IHostOpenHandler.call(this);
    }

    MyHostOpenHandler2.prototype = Object.create(SOL_SERVICES_OPEN_2015_10.IHostOpenHandler.prototype);

    MyHostOpenHandler2.prototype.handleOpen = function (message) {
        var logMsg = "**** [Host Open 2015_10 Message]\n";
        var targets = message.OpenTargets || [];
        for (var i = 0; i < targets.length; i++) {
            var ref = JSON.parse(targets[i].Data);
            logMsg += "  [" + i + "]:" + ref.ObjId + " - " + ref.ObjType + "\n";
        }
        logMsg += "****";

        mylog(logMsg);
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"open\" notification:\n\t--> " + logMsg}});
        myCommSvc.sendMessage({op: 'open', data: message});
    };


    //
    // AW Host side SOA service
    //
    function MyAsyncSoaJsonMessageHandler () {
        INF_SERVICES_SOA_2014_02.IAsyncSoaJsonMessageHandler.call(this);
    }

    MyAsyncSoaJsonMessageHandler.prototype = Object.create(INF_SERVICES_SOA_2014_02.IAsyncSoaJsonMessageHandler.prototype);

    MyAsyncSoaJsonMessageHandler.prototype.handle = function(message) {
        mylog("SOA request: " + message.ServiceName + " - " + message.OperationName);
        myCommSvc.sendMessage({op: 'soaRequest', data: message});
    }

    function soaResponseHandler(data) {
        var state = {
            Version : data.Version,
            CacheId : data.CacheId,
            ReplyServiceDescriptor : data.ReplyServiceDescriptor
        };

        if (data.SoaResponse) {
            mylog("SOA response");
            sendSoaResponse(state, data.SoaResponse, null);
        } else {
            mylog("SOA response - Failed");
            var error = new INF_SERVICES_SOA_2014_02.ExceptionInfo();
            error.name = "SOA request failed";
            error.message = "SOA Request Failed: "+data.ExceptionText;
            sendSoaResponse(state, null, error);
        }
        var clientIFrame = document.getElementById("aw-frame");
		var location = clientIFrame.contentWindow.location;	
        TcICHistory.addNewUrl(location.href);
    }

    function sendSoaResponse(state, replyData, error) {
        var payload;

        if (error && (error.name || error.message))
        {
            var response = new INF_SERVICES_SOA_2014_02.SoaJsonResponseMessage();
            response.Version = state.Version;
            response.CacheId = state.CacheId;
            response.Exception = error;
            payload = JSON.stringify(response);
        }
        else
        {
            if (state.Version === IInfrastructureServiceConstants.VERSION_2015_10) {
                // To avoid having to parse & re-stringify the SOA response data
                // manually build the surrounding JSON payload string around it.
                payload = '{'+
                              '"Version":"'+state.Version+'",'+
                              '"CacheId":"'+state.CacheId+'",'+
                              '"SoaResponse":'+replyData+
                          '}';
            } else {
                var response = new INF_SERVICES_SOA_2014_02.SoaJsonResponseMessage();
                response.Version = state.Version;
                response.CacheId = state.CacheId;
                response.SoaResponse = INF_UTILS.encodeEmbeddedJson(replyData);
                payload = JSON.stringify(response);
            }
        }

        hostControl.invokeWebEvent(JSON.parse(state.ReplyServiceDescriptor), payload);
    };

    
    //
    // AW Host side SOA session info service
    //
    var sessionInfo = {
            userName: null,
            isSessionActive: false,
            awFrameUrlFromPerviousSession: ""
    }

    function MyHostSessionInfoProvider()
    {
        // This prototype will always have a SOA connection established before loading AW
        return new INF_SERVICES_SOA_2014_02.HostSessionInfoResponseMsg(sessionInfo.userName, sessionInfo.isSessionActive);
    }

    //
    // AW Host side SOA Auth service
    //
    function MyRequestHostAuthHandler () {
        INF_SERVICES_SOA_2014_02.IRequestHostAuthHandler.call(this);
    }

    MyRequestHostAuthHandler.prototype = Object.create(INF_SERVICES_SOA_2014_02.IRequestHostAuthHandler.prototype);

    MyRequestHostAuthHandler.prototype.handle = function(state) {
        mylog("Auth request");
        myCommSvc.sendMessage({op: 'authRequest', data: { state : state }});
    }

    var requestHostAuthProxy = null;
    function authResponseHandler(data) {
        if (requestHostAuthProxy === null) {
            requestHostAuthProxy = new INF_SERVICES_SOA_2014_02.RequestHostAuthProxy(hostControl);
        }

        requestHostAuthProxy.sendResponse(data.state, data.isAuth, data.error);
    }
    
    var startup_notification = false;
    var MyStartupNotificationSvc = function( ) {
        INF_SERVICES.BaseHostingService.call( this, IInfrastructureServiceConstants.HS_CS_STARTUP_NOTIFICATION_SVC,
                IInfrastructureServiceConstants.VERSION_2014_02 );
    };

    MyStartupNotificationSvc.prototype = Object.create( INF_SERVICES.BaseHostingService.prototype );

    MyStartupNotificationSvc.prototype.doInvokeEvent = function( hostControl, descriptor ) {
        try {
            mylog("startup notification");
            if(!startup_notification){
            	myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Send \"startup\" notification"}});
            	startup_notification = true;
            }
            getClientInfo();
        } catch( ex ) {
            INF_UTILS.logError( ex );
        }
    };
    
    
    
    var clientInfoProxy = null;
    function getClientInfo() {
        if (clientInfoProxy === null) {
            clientInfoProxy = new INF_SERVICES_CLIENTINFO_2014_07.ClientInfoProxy(hostControl);
        }
        
        var info = clientInfoProxy.getClientInfo();
        mylog("client info: " + JSON.stringify(info));
        //send to webSocket
        myCommSvc.sendMessage({op: 'ClientInfo', data: info});        
    }


    // Initialize Active Workspace -- register services and set iframe src
    function initAW(data)
    {
        mylog("initAW called");
        TcICHistory.resetHistory();
       
        var clientIFrame = document.getElementById("aw-frame");
        
        var services = data.services || {};
        
        if (data.configSettings) {
            for (var prop in data.configSettings) {
                hostConfigurationSettings[prop] = data.configSettings[prop];
            }
        }

        if (data.sessionInfo) {
            for (var prop in data.sessionInfo) {
                sessionInfo[prop] = data.sessionInfo[prop];
            }
        }
        
        var services_registration = "\n\t--> Register Services:";
        var hostManager = INF_INTEROP.getHostManagerInstance();
        var hostServices = hostManager.getKnownServices();
        if( hostServices || hostServices.length == 0 ) {
            hostControl = hostManager.initializeHostIntegration(clientIFrame, function (hostManager) {
                // register host configuration
                hostManager.registerService(new INF_SERVICES_CORE_2014_07.HostConfigurationSvc(new MyHostConfiguration()));
                services_registration = services_registration + "\n\t\t- INF_SERVICES_CORE_2014_07.HostConfigurationSvc";
                
                // register startup notification
                hostManager.registerService(new MyStartupNotificationSvc());
                services_registration = services_registration + "\n\t\t- IInfrastructureServiceConstants.VERSION_2014_02.HS_CS_STARTUP_NOTIFICATION_SVC";
                
                // register client status
                hostManager.registerService(new INF_SERVICES_CORE_2014_07.ClientStatusSvc(new MyClientStatusHandler()));
                services_registration = services_registration + "\n\t\t- INF_SERVICES_CORE_2014_07.ClientStatusSvc";
                
                // register SOA service
                hostManager.registerService(new INF_SERVICES_SOA_2014_02.AsyncSoaJsonMessageSvc(new MyAsyncSoaJsonMessageHandler()));
                services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.AsyncSoaJsonMessageSvc";
                
                // register Auth request service
                hostManager.registerService(new INF_SERVICES_SOA_2014_02.RequestHostAuthSvc(new MyRequestHostAuthHandler()));
                services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.RequestHostAuthSvc";
                
                // register Session Info service
                hostManager.registerService(new INF_SERVICES_SOA_2014_02.HostSessionInfoSvc(MyHostSessionInfoProvider));
                services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.HostSessionInfoSvc";

                // register logger
                if (services.log) {
                    hostManager.registerService(new INF_SERVICES_LOGGING_2014_02.LoggerForwardSvc(new MyLogEntryHandler()));
                    services_registration = services_registration + "\n\t\t- INF_SERVICES_LOGGING_2014_02.LoggerForwardSvc";
                }

                // register selection listener
                if (services.selection) {
                    var selectionProviderSvc = new SOL_SERVICES_SELECTION_2014_10.SelectionProviderSvc();
                    selectionProviderSvc.addListener(new MySelectionChangeListener2014_10());
                    hostManager.registerService(selectionProviderSvc);
                    services_registration = services_registration + "\n\t\t- SOL_SERVICES_SELECTION_2014_10.SelectionProviderSvc";
                }
                
                // register clipboard listener
                if (services.clipboard) {
                    var clipboardSvc = new SOL_SERVICES_CLIPBOARD_2014_02.RemoteClipboardSvc();
                    clipboardSvc.addListener(new MyRemoteClipboardChangeListener());
                    hostManager.registerService(clipboardSvc);
                    services_registration = services_registration + "\n\t\t- SOL_SERVICES_CLIPBOARD_2014_02.RemoteClipboardSvc";
                }
                
                // register refresh listener
                if (services.refresh) {
                    var refreshSvc = new INF_SERVICES_REFRESH_2014_07.RefreshSvc(new MyRefreshHandler());
                    hostManager.registerService(refreshSvc);
                    services_registration = services_registration + "\n\t\t- INF_SERVICES_REFRESH_2014_07.RefreshSvc";
                }

                // register session listener
                if (services.session) {
                    var sessionSvc = new INF_SERVICES_SESSION_2014_07.SessionSvc(new MySessionHandler());
                    hostManager.registerService(sessionSvc);
                    services_registration = services_registration + "\n\t\t- INF_SERVICES_SESSION_2014_07.SessionSvc";
                }

                // register open handler
                if (services.open) {
                    var openSvc = new SOL_SERVICES_OPEN_2014_02.HostOpenSvc(new MyHostOpenHandler());
                    hostManager.registerService(openSvc);
                    services_registration = services_registration + "\n\t\t- SOL_SERVICES_OPEN_2014_02.HostOpenSvc";
                }
            });
        }

        var url = data.awpath+'?ah=true';
        if ((sessionInfo.awFrameUrlFromPerviousSession != undefined) && (sessionInfo.awFrameUrlFromPerviousSession != null) && (sessionInfo.awFrameUrlFromPerviousSession !== "")) {
            url = sessionInfo.awFrameUrlFromPerviousSession;
            sessionInfo.awFrameUrlFromPerviousSession = "";
        }
        clientIFrame.src = url;
        mylog("set iframe src: " + url);
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Active Workspace Initialization:\n\t--> " + url + services_registration}});
        
    }

    var shapeSearchProxy = null;
    function sendInfoToGeolus(data) {
    	// Create the Interop query object.    	
        if (null === shapeSearchProxy) {
        	shapeSearchProxy = new SOL_SERVICES_INTEROPQUERY_2015_10.InteropQueryProxy(hostControl);
        }

        // Construct message object to passed to Interop query. 
        // Data is passed in key value pair.
        var msgObj = {
        		Queries : [
        			{
        			     // This is ID of the Shape search Interop query.
        				QueryId :"com.siemens.splm.client.hosted.IsShapeSearchQueryHandlerAvailable",               
                        IsResponse : false,
                        DataObjects : [
                        	{
                        		DataFields : [
                        			{
                        				Key : "string:QueryId",
                                        Value : "com.siemens.splm.client.hosted.IsShapeSearchQueryHandlerAvailable"
                                    },
                                    {
                                    	// FMS Read ticket for file uploaded in
                                    	// Transient Volume.
                                    	Key : "string:GeolusXMLfmsTicket",   
                                    	Value : data.ticket
                                    },
                                    {
                                    	// This value will be displayed given in 
                                    	// Search Panel in Active Workspace UI.
                                    	Key: "string:SearchDisplayName",   
                                    	Value: "*"
                                    }
                                ]
                        	}
                        ]
                     }
        		]
             };
        // Send query to AW Client from host.
        shapeSearchProxy.sendQueries(msgObj);

    }

    // Page onload function -- initialize communication service
    MY_HOST.onload = function () {
        mylog("MY_HOST.onload called");
        
        mylog(navigator.userAgent);
        if (document.documentMode) {
            mylog('documentMode: '+document.documentMode)
        }
        
        myCommSvc = new MY_COMM.CommService(directComm, localPort, mylog);
        myCommSvc.registerHandler('opFailed', function(data)
        {
            mylog("WS operation "+data.origOp+" failed: "+data.error);
            myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Operation "+data.origOp +" failed: "+ data.error}});
        })
        myCommSvc.sendMessage({op: 'DebugMsg', data: {"msg" :"Host loading..."}});
        myCommSvc.registerHandler('initComplete', initAW);
        myCommSvc.registerHandler('soaResponse', soaResponseHandler);
        myCommSvc.registerHandler('authResponse', authResponseHandler);
        myCommSvc.registerHandler('selection', setSelection);
        myCommSvc.registerHandler('clipboard', setClipboard);
        myCommSvc.registerHandler('refresh', sendRefresh);
        myCommSvc.registerHandler('session', sendSession);
        myCommSvc.registerHandler('openLocation', openLocation);       
		myCommSvc.registerHandler('refreshAWHostedPage', sendRefreshAWHostedPage);
		myCommSvc.registerHandler('goBackOnePage', sendGoBackOnePage);
		myCommSvc.registerHandler('goForwardOnePage', sendGoForwardOnePage);
		myCommSvc.registerHandler('sendInfoToGeolus', sendInfoToGeolus);
        myCommSvc.registerHandler('getCurrentAwFrameUrl', getCurrentAwFrameUrl);
        
        myCommSvc.connect({op: 'init'});
    }

})(window.MY_HOST = window.MY_HOST || {});
(function(MY_SUMMARY_HOST)
{
	var _uid = "";
	var _type = "";
	var _db = "";
	var _toolbar_and_separator_height = 35;
	var showInTeamcenterMsg = {'op': 'showInTeamcenter','data':{'uid' : ""}}
    
    function mylog(msg)
    {
        var con = document.getElementById("console");
        var line = document.createTextNode(msg + "\n");
        con.appendChild(line);
        con.scrollTop = con.scrollHeight;
    }    
    MY_SUMMARY_HOST.mylog = mylog;
    
    function animLoadingPage()
    {
        $(".LoadingElement").each(function(){
            $(this).rotate({
                angle: 0,
                animateTo:360,
                callback: animLoadingPage,
                easing: function (x,t,b,c,d){
                    return c*(t/d)+b;
                }
            })        
        });
    }
    
    // utility function for creating a single InteropObjectRef instances from an object with uid, db, and type properties
    function makeObjectRef(obj) {
        return new INF_SERVICES_CORE_2014_02.InteropObjectRef(obj.uid, obj.db, obj.type);
    }

    // utility function for creating array of InteropObjectRef instances from objects with uid, db, and type properties
    function makeObjectRefs(objs) {
        var refs = [];

        if (objs)
        {
            if (Array.isArray(objs))
            {
                for (var i=0; i<objs.length; ++i)
                {
                    refs.push(makeObjectRef(objs[i]));
                }
            }
            else if (objs.uid)
            {
                // looks like just one object
                refs.push(makeObjectRef(objs));
            }
        }

        return refs;
    }
    
    var localPort = 3000;
    var directComm = true;
    if (location.search.length > 1)
    {
        var params = location.search.substr(1).split("&");
        for (var i = 0; i < params.length; ++i)
        {
            var kv = params[i].split("=");
            var key = decodeURIComponent(kv[0]);
            if (key == 'port' && kv.length > 1)
            {
                localPort = decodeURIComponent(kv[1]);
            }
            else if (key == 'direct' && kv.length > 1) {
                directComm = decodeURIComponent(kv[1]) === 'true';
            }
        }
    }
   
    var myCommSvc = null;
    var hostControl = null;      

    //
    // AW Host side configuration service
    //
    function MyHostConfiguration() {
        INF_SERVICES_CORE_2014_07.IHostConfigurationHandler.call(this);
    }

    MyHostConfiguration.prototype = Object.create(INF_SERVICES_CORE_2014_07.IHostConfigurationHandler.prototype);

    // Default settings -- can be overridden by initComplete/initAW
    var hostConfigurationSettings =
    {
            AllowGoHome: 'true',
            AllowThemeChange: 'true',
            AllowGroupRoleChange: 'false',
            HostType: 'MyHostTest',
            HasFullScreenSupport: 'false',
            ShowSiemensLogo: 'true',
            Theme: 'com.siemens.splm.clientfx.ui.lightTheme',
            HostSupportsMultipleSelection: 'true',
    };
    
    MyHostConfiguration.prototype.handleHostConfigurationRequest = function ()
    {
        mylog("host settings request");
        var host_setting_info = "";
        var settings = [];
        for (var prop in hostConfigurationSettings) {
            settings.push(new INF_SERVICES.Pair(prop, hostConfigurationSettings[prop]));
            host_setting_info=host_setting_info + "\n\t\t- " + prop + "= " + hostConfigurationSettings[prop]; 
        }
       
        return new INF_SERVICES_CORE_2014_07.HostConfigurationResponseMsg(settings);
    };


    //
    // AW Host side logging handler
    //
    function MyLogEntryHandler () {
        INF_SERVICES_LOGGING_2014_02.ILogEntryHandler.call(this);
    }

    MyLogEntryHandler.prototype = Object.create(INF_SERVICES_LOGGING_2014_02.ILogEntryHandler.prototype);

    MyLogEntryHandler.prototype.handleEntry = function (msg) {
        // Log to page
        mylog("LOG: " + msg.getFormatMessage());
        // And Log to websocket
        myCommSvc.sendMessage({op: 'log', data: msg});
    };


    //
    // AW Host side client status handler
    //
    function MyClientStatusHandler () {
        INF_SERVICES_CORE_2014_07.IClientStatusHandler.call(this);
    }
    
    MyClientStatusHandler.prototype = Object.create(INF_SERVICES_CORE_2014_07.IClientStatusHandler.prototype);

    MyClientStatusHandler.prototype.handleClientStatusUpdate = function (msg)
    {
        mylog("Client Status: " + msg.Status);
        //And send to server
        myCommSvc.sendMessage({op: 'ClientStatus', data: msg.Status});
    }
    
    //
    // AW Host side session change listener
    //
    function MySessionHandler() {
        INF_SERVICES_SESSION_2014_07.ISessionHandler.call(this);
    }
    
    MySessionHandler.prototype = Object.create(INF_SERVICES_SESSION_2014_07.ISessionHandler.prototype);
    
    MySessionHandler.prototype.handle = function( message ) {
        // Log to page
        mylog("session = " + JSON.stringify(message));
        // And send to server
        myCommSvc.sendMessage({op: 'session', data: message});
    }

    //
    // Host function for passing session changes to AW
    //
    var sessionProxy = null;
    function sendSession(data) {
        if (null === sessionProxy) {
            sessionProxy = new INF_SERVICES_SESSION_2014_07.SessionProxy(hostControl);
        }
        
        sessionProxy.sendSession(
                makeObjectRefs(data.sessionObjects),
                data.preferences
        );
    }

    //
    // AW Host side SOA service
    //
    function MyAsyncSoaJsonMessageHandler () {
        INF_SERVICES_SOA_2014_02.IAsyncSoaJsonMessageHandler.call(this);
    }

    MyAsyncSoaJsonMessageHandler.prototype = Object.create(INF_SERVICES_SOA_2014_02.IAsyncSoaJsonMessageHandler.prototype);

    MyAsyncSoaJsonMessageHandler.prototype.handle = function(message) {
        mylog("SOA request: " + message.ServiceName + " - " + message.OperationName);
        myCommSvc.sendMessage({op: 'soaRequest', data: message});
    }

    function soaResponseHandler(data) {
        var state = {
            Version : data.Version,
            CacheId : data.CacheId,
            ReplyServiceDescriptor : data.ReplyServiceDescriptor
        };

        if (data.SoaResponse) {
            mylog("SOA response");
            sendSoaResponse(state, data.SoaResponse, null);
        } else {
            mylog("SOA response - Failed");
            var error = new INF_SERVICES_SOA_2014_02.ExceptionInfo();
            error.name = "SOA request failed";
            error.message = "SOA Request Failed: "+data.ExceptionText;
            sendSoaResponse(state, null, error);
        }
    }

    function sendSoaResponse(state, replyData, error) {
        var payload;

        if (error && (error.name || error.message))
        {
            var response = new INF_SERVICES_SOA_2014_02.SoaJsonResponseMessage();
            response.Version = state.Version;
            response.CacheId = state.CacheId;
            response.Exception = error;
            payload = JSON.stringify(response);
        }
        else
        {
            if (state.Version === IInfrastructureServiceConstants.VERSION_2015_10) {
                // To avoid having to parse & re-stringify the SOA response data
                // manually build the surrounding JSON payload string around it.
                payload = '{'+
                              '"Version":"'+state.Version+'",'+
                              '"CacheId":"'+state.CacheId+'",'+
                              '"SoaResponse":'+replyData+
                          '}';
            } else {
                var response = new INF_SERVICES_SOA_2014_02.SoaJsonResponseMessage();
                response.Version = state.Version;
                response.CacheId = state.CacheId;
                response.SoaResponse = INF_UTILS.encodeEmbeddedJson(replyData);
                payload = JSON.stringify(response);
            }
        }

        hostControl.invokeWebEvent(JSON.parse(state.ReplyServiceDescriptor), payload);
    };

    
    //
    // AW Host side SOA session info service
    //
    var sessionInfo = {
            userName: null,
            isSessionActive: false
    }

    function MyHostSessionInfoProvider()
    {
        // This prototype will always have a SOA connection established before loading AW
        return new INF_SERVICES_SOA_2014_02.HostSessionInfoResponseMsg(sessionInfo.userName, sessionInfo.isSessionActive);
    }

    //
    // AW Host side SOA Auth service
    //
    function MyRequestHostAuthHandler () {
        INF_SERVICES_SOA_2014_02.IRequestHostAuthHandler.call(this);
    }

    MyRequestHostAuthHandler.prototype = Object.create(INF_SERVICES_SOA_2014_02.IRequestHostAuthHandler.prototype);

    MyRequestHostAuthHandler.prototype.handle = function(state) {
        mylog("Auth request");
        myCommSvc.sendMessage({op: 'authRequest', data: { state : state }});
    }

    var requestHostAuthProxy = null;
    function authResponseHandler(data) {
        if (requestHostAuthProxy === null) {
            requestHostAuthProxy = new INF_SERVICES_SOA_2014_02.RequestHostAuthProxy(hostControl);
        }

        requestHostAuthProxy.sendResponse(data.state, data.isAuth, data.error);
    }
    
    var MyStartupNotificationSvc = function( ) {
        INF_SERVICES.BaseHostingService.call( this, IInfrastructureServiceConstants.HS_CS_STARTUP_NOTIFICATION_SVC,
                IInfrastructureServiceConstants.VERSION_2014_02 );
    };

    MyStartupNotificationSvc.prototype = Object.create( INF_SERVICES.BaseHostingService.prototype );

    MyStartupNotificationSvc.prototype.doInvokeEvent = function( hostControl, descriptor ) {
        try {
            mylog("startup notification");           
            getClientInfo();
        } catch( ex ) {
            INF_UTILS.logError( ex );
        }
    };
    
    
    
    var clientInfoProxy = null;
    function getClientInfo(){
        if (clientInfoProxy === null) {
            clientInfoProxy = new INF_SERVICES_CLIENTINFO_2014_07.ClientInfoProxy(hostControl);
        }
        
        var info = clientInfoProxy.getClientInfo();
        mylog("client info: " + JSON.stringify(info));
        //send to webSocket
        myCommSvc.sendMessage({op: 'ClientInfo', data: info});        
    }


    /*Initialize Active Workspace -- register services and set iframe src*/
    function initAW(data)
    {
        mylog("initAW called");
        if(data.showInTcBtnTooltip != null){
        	document.getElementById("showInTcBtn").title = data.showInTcBtnTooltip;
        }        
        var clientIFrame = document.getElementById("aw-frame");        
        var services = data.services || {};        
        if (data.configSettings){
            for (var prop in data.configSettings){
                hostConfigurationSettings[prop] = data.configSettings[prop];
            }
        }

        if (data.sessionInfo){
            for (var prop in data.sessionInfo){
                sessionInfo[prop] = data.sessionInfo[prop];
            }
        }
        
        var error_msg = data.noInfoMessage;
        var html_error_msg = document.getElementById("ErrorDiv-message");
        html_error_msg.innerHTML = error_msg;
        
        var services_registration = "\n\t--> Register Services:";
        var hostManager = INF_INTEROP.getHostManagerInstance();
        var hostServices = hostManager.getKnownServices();
        if( hostServices || hostServices.length == 0 )
        {
            hostControl = hostManager.initializeHostIntegration(clientIFrame, function (hostManager){            
	            // register host configuration
	            hostManager.registerService(new INF_SERVICES_CORE_2014_07.HostConfigurationSvc(new MyHostConfiguration()));
	            services_registration = services_registration + "\n\t\t- INF_SERVICES_CORE_2014_07.HostConfigurationSvc";
	                
	            // register startup notification
	            hostManager.registerService(new MyStartupNotificationSvc());
	            services_registration = services_registration + "\n\t\t- IInfrastructureServiceConstants.VERSION_2014_02.HS_CS_STARTUP_NOTIFICATION_SVC";
	                
	            // register client status
	            hostManager.registerService(new INF_SERVICES_CORE_2014_07.ClientStatusSvc(new MyClientStatusHandler()));
	            services_registration = services_registration + "\n\t\t- INF_SERVICES_CORE_2014_07.ClientStatusSvc";
	                
	            // register SOA service
	            hostManager.registerService(new INF_SERVICES_SOA_2014_02.AsyncSoaJsonMessageSvc(new MyAsyncSoaJsonMessageHandler()));
	            services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.AsyncSoaJsonMessageSvc";
	                
	            // register Auth request service
	            hostManager.registerService(new INF_SERVICES_SOA_2014_02.RequestHostAuthSvc(new MyRequestHostAuthHandler()));
	            services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.RequestHostAuthSvc";
	                
	            // register Session Info service
	            hostManager.registerService(new INF_SERVICES_SOA_2014_02.HostSessionInfoSvc(MyHostSessionInfoProvider));
	            services_registration = services_registration + "\n\t\t- INF_SERVICES_SOA_2014_02.HostSessionInfoSvc";
	
	           // register ClientStatus listener
	           if (services.ClientStatus)
	           {
	                 var clientstatusSvc = new INF_SERVICES_CORE_2014_07.ClientStatusSvc(new MyClientStatusHandler())
	                 hostManager.registerService(clientstatusSvc);
	                 services_registration = services_registration + "\n\t\t- INF_SERVICES_CORE_2014_07.ClientStatusSv";
	            }
            });
        }

        mylog("data.awsummary_url_suffix: " + data.awsummary_url_suffix);        
        var url = data.awpath+'?ah=true'+ data.awsummary_url_suffix;  
        clientIFrame.src = url;
        mylog("set iframe src: " + url);
        var height = document.body.clientHeight - _toolbar_and_separator_height;
    	$("#aw-frame").css("height", height);
    	$("#LoadingDiv").css("height", height);
    	$("#ErrorDiv").css("height", height);
    	animLoadingPage();
    }

    var componentConfigProxy = null;
    var objectInfoProxy = null;
    var componentConfigIsSet = false;
    function updateSummary(data)
    {
    	mylog("updateSummary<"+data.uid+">");
    	$("#LoadingDiv").show();
        $("#aw-frame").hide();
        $("#ErrorDiv").hide();
        
        if(data.uid == null || data.uid === ""){
        	_uid = "";
        	setTimeout(function(){$("#LoadingDiv").hide();$("#ErrorDiv").show();}, 250);
        }
        else{
	    	if (null == componentConfigProxy)
	    	{
	    		componentConfigProxy = new SOL_SERVICES_COMPONENT_2014_07.ComponentConfigProxy(hostControl);
	    	}
	    	if (null == objectInfoProxy){
	    		objectInfoProxy = new SOL_SERVICES_COMPONENT_2014_07.ObjectInfoComponentInputProxy(hostControl);
	    	}
	    	if (!componentConfigIsSet)
	    	{
	    		var objectInfoComponent = "com.siemens.splm.clientfx.tcui.xrt.published.ObjectInfo";
	    		componentConfigProxy.updateConfig(objectInfoComponent, true);
	    		componentConfigIsSet = true;
	    	}
	    	
	    	_type = data.type;
	    	_db = data.db;
	   		_uid = data.uid;
	   		objectInfoProxy.triggerSummary(makeObjectRef(data));   
	   		setTimeout(function(){$("#LoadingDiv").hide();$("#aw-frame").show();}, 500);
        }
    }
    
    function refreshSummaryPage(data_user)
    {
    	mylog("refreshSummaryPage");
    	
    	// Affichage de la page 'Loading' dans le tooltip
    	$("#LoadingDiv").show();
        $("#aw-frame").hide();
        $("#ErrorDiv").hide();
    	
        // Mise a jour du composant AW avec le 'User'
    	objectInfoProxy.triggerSummary(makeObjectRef(data_user));
    	
    	setTimeout(function(){
    		var obj = new INF_SERVICES_CORE_2014_02.InteropObjectRef(_uid, _db, _type);
    		// Mise a jour du composant AW avec l'objet selectionne
    		objectInfoProxy.triggerSummary(obj);
    		// Affichage du composant AW dans le tooltip
    		setTimeout(function(){$("#LoadingDiv").hide();$("#aw-frame").show();}, 500);
    		}, 500);
    }
    
    // Page onload function -- initialize communication service
    MY_SUMMARY_HOST.onload = function () {
        mylog("MY_SUMMARY_HOST.onload called");
        
        mylog(navigator.userAgent);
        if (document.documentMode) {
            mylog('documentMode: '+document.documentMode)
        }
        
        myCommSvc = new MY_SUMMARY_COMM.CommService(directComm, localPort, mylog);
        myCommSvc.registerHandler('opFailed', function(data)
        {
            mylog("WS operation "+data.origOp+" failed: "+data.error);
        })
        myCommSvc.registerHandler('initComplete', initAW);
        myCommSvc.registerHandler('soaResponse', soaResponseHandler);
        myCommSvc.registerHandler('authResponse', authResponseHandler);
		myCommSvc.registerHandler('updateSummary', updateSummary);
		myCommSvc.registerHandler('refreshSummaryPage', refreshSummaryPage);
        myCommSvc.connect({op: 'init'});
        
        $("#showInTcBtn").click(function(event){ 
        	mylog("show in Tc: _uid= " + _uid);
        	showInTeamcenterMsg.data.uid = _uid;
        	myCommSvc.sendMessage(showInTeamcenterMsg);
        });
        
        $(window).resize(function()
        {
        	var height = document.body.clientHeight - _toolbar_and_separator_height;
        	$("#aw-frame").css("height", height);
        	$("#LoadingDiv").css("height", height);
        	$("#ErrorDiv").css("height", height);
        });
    }

})(window.MY_SUMMARY_HOST = window.MY_SUMMARY_HOST || {});